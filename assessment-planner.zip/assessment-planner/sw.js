// sw.js — minimal service worker. Its main job here is to let the app use
// registration.showNotification() for the D-2 reminder. It also caches the
// core files so the app opens even with a flaky connection.
const CACHE_NAME = "ap-cache-v1";
const CORE_FILES = [
  "./",
  "index.html",
  "css/style.css",
  "js/store.js",
  "js/ai.js",
  "js/notifications.js",
  "js/app.js",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_FILES))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clients) => {
      if (clients.length > 0) return clients[0].focus();
      return self.clients.openWindow("./");
    })
  );
});
