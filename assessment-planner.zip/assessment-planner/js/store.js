// store.js — everything is saved to this device only, via localStorage.
const Store = (() => {
  const KEYS = {
    assessments: "ap_assessments",
    history: "ap_history",
    settings: "ap_settings",
    notified: "ap_notified",
  };

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.error("저장소 읽기 실패:", key, e);
      return fallback;
    }
  }
  function write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  // ---------- assessments ----------
  function getAssessments() {
    return read(KEYS.assessments, []);
  }
  function saveAssessment(assessment) {
    const all = getAssessments();
    const idx = all.findIndex((a) => a.id === assessment.id);
    if (idx >= 0) all[idx] = assessment;
    else all.push(assessment);
    write(KEYS.assessments, all);
    return assessment;
  }
  function deleteAssessment(id) {
    write(KEYS.assessments, getAssessments().filter((a) => a.id !== id));
  }
  function getAssessment(id) {
    return getAssessments().find((a) => a.id === id) || null;
  }

  // ---------- AI history ----------
  function getHistory() {
    return read(KEYS.history, []);
  }
  function addHistory(entry) {
    const all = getHistory();
    all.unshift(entry); // newest first
    write(KEYS.history, all);
    return entry;
  }

  // ---------- settings ----------
  function getSettings() {
    return read(KEYS.settings, { apiKey: "" });
  }
  function saveSettings(settings) {
    write(KEYS.settings, settings);
  }

  // ---------- notification tracking (avoid duplicate D-2 alerts) ----------
  function getNotified() {
    return read(KEYS.notified, {});
  }
  function markNotified(assessmentId, dayKey) {
    const n = getNotified();
    n[assessmentId] = dayKey;
    write(KEYS.notified, n);
  }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  return {
    getAssessments, saveAssessment, deleteAssessment, getAssessment,
    getHistory, addHistory,
    getSettings, saveSettings,
    getNotified, markNotified,
    uid,
  };
})();
