// notifications.js — asks for browser notification permission and fires a
// reminder when an assessment reaches D-2. This only fires while the app
// (or its service worker) is active in the browser — see README for the
// limits of this on a static, backend-less site.

const Notifier = (() => {

  let swRegistration = null;

  async function init() {
    if ("serviceWorker" in navigator) {
      try {
        swRegistration = await navigator.serviceWorker.register("sw.js");
      } catch (e) {
        console.warn("서비스 워커 등록 실패 (알림은 여전히 동작할 수 있어요):", e);
      }
    }
    checkAll();
    setInterval(checkAll, 30 * 60 * 1000); // re-check every 30 minutes
  }

  async function requestPermission() {
    if (!("Notification" in window)) {
      alert("이 브라우저는 알림을 지원하지 않아요.");
      return false;
    }
    const perm = await Notification.requestPermission();
    return perm === "granted";
  }

  function fire(title, body) {
    if (Notification.permission !== "granted") return;
    if (swRegistration && swRegistration.showNotification) {
      swRegistration.showNotification(title, { body, icon: "icon.svg" });
    } else {
      new Notification(title, { body });
    }
  }

  function todayKey() {
    return new Date().toISOString().slice(0, 10);
  }

  function checkAll() {
    if (Notification.permission !== "granted") return;
    const assessments = Store.getAssessments();
    const notified = Store.getNotified();
    const key = todayKey();

    assessments.forEach((a) => {
      if (a.status === "done") return;
      const d = AI.daysUntil(a.due);
      if (d === 2 && notified[a.id] !== key) {
        fire(
          `D-2 · ${a.subject || "수행평가"}`,
          `${a.title || "제목 없음"} 이(가) 이틀 뒤예요. 지금 준비 상황을 확인해 보세요.`
        );
        Store.markNotified(a.id, key);
      }
    });
  }

  return { init, requestPermission, checkAll };
})();
