// ai.js — builds a prompt tailored to the assessment type, calls Gemini,
// and turns the reply into a checklist + feedback the app can store/render.

const AI = (() => {

  const TYPE_LABEL = {
    writing: "글쓰기 · 서술형",
    presentation: "발표",
    experiment: "실험 · 탐구",
    etc: "기타",
  };

  // Each type gets its own instructions, so the outline/schedule/feedback
  // actually fits how that kind of assessment is graded.
  const TYPE_INSTRUCTIONS = {
    writing: `이 학생은 글쓰기/서술형 수행평가를 준비하고 있습니다.
- 먼저 서론-본론-결론 구조의 글쓰기 아웃라인을 문단별 핵심 문장과 함께 제시하세요.
- 채점자가 좋아할 만한 논거 배치, 인용/근거 넣을 위치를 짚어주세요.
- 마감일까지 남은 일수에 맞춰 "초안 작성 → 퇴고 → 분량/형식 점검" 단계별 준비 일정을 짜주세요.
- 흔한 감점 요인(주제 이탈, 분량 미달, 결론 없이 끝남 등)을 피드백으로 알려주세요.`,
    presentation: `이 학생은 발표 수행평가를 준비하고 있습니다.
- 도입(주의 환기)-본론(핵심 근거 2~3개)-결론(요약/마무리 멘트) 구조로 발표 개요를 짜주세요.
- 슬라이드가 필요하다면 슬라이드별로 들어갈 내용을 한 줄씩 제시하세요.
- 제한 시간이 언급되어 있다면 그 시간에 맞춘 분량으로 조절하세요.
- 마감일까지 "자료조사 → 대본 작성 → 리허설 → 시간 체크" 단계별 준비 일정을 짜주세요.
- 발표 특유의 감점 요인(시간 초과, 눈맞춤 없이 읽기, 근거 부족)에 대한 피드백을 주세요.`,
    experiment: `이 학생은 실험/탐구 수행평가를 준비하고 있습니다.
- 실험의 가설-준비물-절차-예상 결과-주의사항을 항목별로 정리하세요.
- 보고서를 쓴다면 보고서 목차(가설/방법/결과/고찰)도 함께 제시하세요.
- 마감일까지 "준비물 확인 → 실험/관찰 → 결과 정리 → 보고서 작성" 단계별 준비 일정을 짜주세요.
- 실험 특유의 감점 요인(안전수칙 누락, 변인 통제 실패, 고찰 부실)에 대한 피드백을 주세요.`,
    etc: `이 학생은 위 내용의 수행평가를 준비하고 있습니다.
- 과제 내용을 분석해서 요구사항을 항목별로 정리하세요.
- 마감일까지 남은 일수에 맞춰 단계별 준비 일정을 짜주세요.
- 놓치기 쉬운 감점 요인에 대한 피드백을 주세요.`,
  };

  function buildPrompt(assessment, extraSourceText) {
    const daysLeft = daysUntil(assessment.due);
    return `너는 한국 고등학생의 수행평가 준비를 도와주는 선생님이야. 아래 정보를 바탕으로 답해줘.

[과목] ${assessment.subject || "미상"}
[제목] ${assessment.title || "미상"}
[유형] ${TYPE_LABEL[assessment.type] || "기타"}
[마감일까지 남은 일수] ${daysLeft}일
[안내 내용]
${assessment.desc || "(안내 내용 없음)"}
${extraSourceText ? `\n[업로드된 유인물/자료 내용]\n${extraSourceText.slice(0, 6000)}` : ""}

${TYPE_INSTRUCTIONS[assessment.type] || TYPE_INSTRUCTIONS.etc}

반드시 아래 형식의 순수 JSON 객체 하나만 출력해. 코드블록, 설명, 다른 텍스트를 절대 붙이지 마.
{
  "outline": "마크다운 형식의 아웃라인/구조 (## 소제목 사용 가능)",
  "schedule": [ {"label": "짧은 단계 이름", "detail": "무엇을 할지 한 줄 설명"} ],
  "feedback": "이 유형에서 흔히 감점되는 부분과 이번 과제에서 특히 주의할 점 (2~4문장)"
}
"schedule" 배열은 남은 일수에 맞춰 2~5단계로 구성해줘.`;
  }

  function daysUntil(dueStr) {
    if (!dueStr) return "미정";
    const due = new Date(dueStr + "T00:00:00");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diff = Math.round((due - today) / 86400000);
    return diff;
  }

  // Free-tier model as of late 2026. Google renames/retires models over
  // time — if this stops working, check https://ai.google.dev/gemini-api/docs/models
  // and swap the string below.
  const GEMINI_MODEL = "gemini-3.1-flash-lite";

  async function callGemini(prompt) {
    const { apiKey } = Store.getSettings();
    if (!apiKey) {
      throw new Error("NO_API_KEY");
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7 },
      }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`API_ERROR_${res.status}: ${text.slice(0, 300)}`);
    }
    const data = await res.json();
    const text = (data.candidates?.[0]?.content?.parts || [])
      .map((p) => p.text || "")
      .join("\n")
      .trim();
    if (!text) throw new Error("API_ERROR_EMPTY: 모델이 빈 응답을 반환했어요.");
    return parseJsonReply(text);
  }

  function parseJsonReply(text) {
    const cleaned = text.replace(/^```json/i, "").replace(/```$/, "").trim();
    try {
      return JSON.parse(cleaned);
    } catch (e) {
      // fall back: show raw text as the outline so nothing is lost
      return { outline: text, schedule: [], feedback: "" };
    }
  }

  // Runs the whole flow for one assessment and returns a result object.
  async function prepareAssessment(assessment, extraSourceText) {
    const prompt = buildPrompt(assessment, extraSourceText);
    const result = await callGemini(prompt);
    return result;
  }

  // ---------- PDF / TXT reading ----------
  async function extractFileText(file) {
    if (!file) return "";
    if (file.type === "text/plain" || file.name.endsWith(".txt")) {
      return await file.text();
    }
    if (file.type === "application/pdf" || file.name.endsWith(".pdf")) {
      return await extractPdfText(file);
    }
    return "";
  }

  async function extractPdfText(file) {
    if (typeof pdfjsLib === "undefined") return "";
    pdfjsLib.GlobalWorkerOptions.workerSrc =
      "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
    const buf = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
    let out = "";
    const maxPages = Math.min(pdf.numPages, 10);
    for (let i = 1; i <= maxPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      out += content.items.map((it) => it.str).join(" ") + "\n";
    }
    return out;
  }

  return { prepareAssessment, extractFileText, daysUntil, TYPE_LABEL };
})();
