// app.js — wires the UI to Store / AI / Notifier.

document.addEventListener("DOMContentLoaded", () => {
  Notifier.init();
  bindTabs();
  bindSettings();
  bindNotifButton();
  bindForm();
  bindModals();
  renderBoard();
  renderArchive();
});

// ---------------- tabs ----------------
function bindTabs() {
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });
  document.querySelectorAll("[data-goto]").forEach((btn) => {
    btn.addEventListener("click", () => switchTab(btn.dataset.goto));
  });
}
function switchTab(name) {
  document.querySelectorAll(".tab-btn").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
  document.querySelectorAll(".tab-panel").forEach((p) => p.classList.toggle("active", p.id === `tab-${name}`));
}

// ---------------- settings modal ----------------
function bindSettings() {
  const modal = document.getElementById("settings-modal");
  document.getElementById("btn-settings").addEventListener("click", () => {
    document.getElementById("f-apikey").value = Store.getSettings().apiKey || "";
    modal.hidden = false;
  });
  document.getElementById("settings-modal-close").addEventListener("click", () => (modal.hidden = true));
  document.getElementById("btn-save-key").addEventListener("click", () => {
    const key = document.getElementById("f-apikey").value.trim();
    Store.saveSettings({ apiKey: key });
    modal.hidden = true;
    showToast("API 키를 저장했어요.");
  });
}

function bindNotifButton() {
  const btn = document.getElementById("btn-notif");
  btn.addEventListener("click", async () => {
    const ok = await Notifier.requestPermission();
    if (ok) {
      btn.textContent = "🔔 알림 켜짐";
      Notifier.checkAll();
      showToast("D-2 알림을 켰어요. 이 브라우저를 열어두면 알려드려요.");
    } else {
      showToast("알림 권한이 꺼져 있어요. 브라우저 설정에서 허용해 주세요.");
    }
  });
  if ("Notification" in window && Notification.permission === "granted") {
    btn.textContent = "🔔 알림 켜짐";
  }
}

// ---------------- new assessment form ----------------
function bindForm() {
  const fileInput = document.getElementById("f-file");
  fileInput.addEventListener("change", () => {
    const f = fileInput.files[0];
    document.getElementById("file-status").textContent = f ? `첨부됨: ${f.name}` : "";
  });

  document.getElementById("btn-save").addEventListener("click", async () => {
    await saveFromForm(false);
  });
  document.getElementById("btn-save-analyze").addEventListener("click", async () => {
    await saveFromForm(true);
  });
}

function readForm() {
  return {
    subject: document.getElementById("f-subject").value.trim(),
    type: document.getElementById("f-type").value,
    title: document.getElementById("f-title").value.trim(),
    due: document.getElementById("f-due").value,
    desc: document.getElementById("f-desc").value.trim(),
  };
}

function clearForm() {
  ["f-subject", "f-title", "f-due", "f-desc"].forEach((id) => (document.getElementById(id).value = ""));
  document.getElementById("f-type").selectedIndex = 0;
  document.getElementById("f-file").value = "";
  document.getElementById("file-status").textContent = "";
}

async function saveFromForm(runAI) {
  const form = readForm();
  if (!form.title) {
    showToast("제목을 입력해 주세요.");
    return;
  }
  const assessment = {
    id: Store.uid(),
    ...form,
    checklist: [],
    status: "active",
    createdAt: new Date().toISOString(),
  };
  Store.saveAssessment(assessment);
  const file = document.getElementById("f-file").files[0];
  clearForm();
  renderBoard();
  switchTab("board");
  showToast("수행평가를 등록했어요.");

  if (runAI) {
    let fileText = "";
    if (file) {
      showToast("첨부 파일을 읽는 중...");
      try {
        fileText = await AI.extractFileText(file);
      } catch (e) {
        console.error(e);
      }
    }
    await runAssistant(assessment.id, fileText);
  }
}

// ---------------- board rendering ----------------
function renderBoard() {
  const all = Store.getAssessments();
  const list = document.getElementById("board-list");
  const empty = document.getElementById("board-empty");
  list.innerHTML = "";
  empty.hidden = all.length > 0;

  document.getElementById("stat-total").textContent = all.length;
  document.getElementById("stat-soon").textContent = all.filter(
    (a) => a.status !== "done" && typeof AI.daysUntil(a.due) === "number" && AI.daysUntil(a.due) <= 3 && AI.daysUntil(a.due) >= 0
  ).length;
  document.getElementById("stat-done").textContent = all.filter((a) => a.status === "done").length;

  // soonest first
  const sorted = [...all].sort((a, b) => {
    const da = a.due ? new Date(a.due) : new Date("2999-01-01");
    const db = b.due ? new Date(b.due) : new Date("2999-01-01");
    return da - db;
  });

  sorted.forEach((a) => list.appendChild(renderBoardItem(a)));
}

function renderBoardItem(a) {
  const el = document.createElement("div");
  const d = AI.daysUntil(a.due);
  const isUrgent = typeof d === "number" && d <= 2 && d >= 0 && a.status !== "done";
  el.className = "board-item" + (isUrgent ? " urgent" : "") + (a.status === "done" ? " done" : "");

  const total = a.checklist.length;
  const doneCount = a.checklist.filter((c) => c.done).length;
  const pct = total ? Math.round((doneCount / total) * 100) : 0;

  el.innerHTML = `
    <div class="board-item-head">
      <div class="board-item-title">
        ${a.subject ? `<span class="chip subject">${escapeHtml(a.subject)}</span>` : ""}
        <span class="chip type-${a.type}">${AI.TYPE_LABEL[a.type] || "기타"}</span>
      </div>
      <span class="dday ${badgeClass(d, a.status)}">${ddayLabel(d, a.status)}</span>
    </div>
    <h3>${escapeHtml(a.title)}</h3>
    ${a.desc ? `<p>${escapeHtml(a.desc)}</p>` : ""}
    ${total ? `
      <div class="progress-row">
        <div class="progress-bar"><span style="width:${pct}%"></span></div>
        <span class="progress-pct">${pct}%</span>
      </div>
      <div class="checklist">
        ${a.checklist.map((c) => `
          <label>
            <input type="checkbox" data-assessment="${a.id}" data-item="${c.id}" ${c.done ? "checked" : ""}/>
            <span><strong>${escapeHtml(c.label)}</strong>${c.detail ? " — " + escapeHtml(c.detail) : ""}</span>
          </label>`).join("")}
      </div>` : `<p class="muted">아직 준비 일정이 없어요. 아래 버튼으로 AI 도우미를 실행해 보세요.</p>`}
    <div class="item-actions">
      <button class="ghost-btn" data-action="ai" data-id="${a.id}">✨ AI 준비 도우미</button>
      ${a.status !== "done" ? `<button class="ghost-btn" data-action="done" data-id="${a.id}">완료로 표시</button>` : `<button class="ghost-btn" data-action="undone" data-id="${a.id}">완료 취소</button>`}
      <button class="ghost-btn" data-action="delete" data-id="${a.id}">삭제</button>
    </div>
  `;

  el.querySelectorAll('input[type=checkbox]').forEach((cb) => {
    cb.addEventListener("change", () => toggleChecklistItem(a.id, cb.dataset.item, cb.checked));
  });
  el.querySelector('[data-action="ai"]').addEventListener("click", () => runAssistant(a.id, ""));
  const doneBtn = el.querySelector('[data-action="done"]');
  if (doneBtn) doneBtn.addEventListener("click", () => setStatus(a.id, "done"));
  const undoneBtn = el.querySelector('[data-action="undone"]');
  if (undoneBtn) undoneBtn.addEventListener("click", () => setStatus(a.id, "active"));
  el.querySelector('[data-action="delete"]').addEventListener("click", () => {
    if (confirm("이 수행평가를 삭제할까요? 관련 기록은 남아있어요.")) {
      Store.deleteAssessment(a.id);
      renderBoard();
    }
  });

  return el;
}

function badgeClass(d, status) {
  if (status === "done") return "past";
  if (typeof d !== "number") return "normal";
  if (d < 0) return "past";
  if (d <= 2) return "soon";
  return "normal";
}
function ddayLabel(d, status) {
  if (status === "done") return "완료";
  if (typeof d !== "number") return "날짜 미정";
  if (d === 0) return "D-DAY";
  if (d < 0) return `${-d}일 지남`;
  return `D-${d}`;
}

function toggleChecklistItem(assessmentId, itemId, checked) {
  const a = Store.getAssessment(assessmentId);
  if (!a) return;
  const item = a.checklist.find((c) => c.id === itemId);
  if (item) item.done = checked;
  Store.saveAssessment(a);
  renderBoard();
}
function setStatus(assessmentId, status) {
  const a = Store.getAssessment(assessmentId);
  if (!a) return;
  a.status = status;
  Store.saveAssessment(a);
  renderBoard();
}

// ---------------- AI assistant flow ----------------
async function runAssistant(assessmentId, extraSourceText) {
  const a = Store.getAssessment(assessmentId);
  if (!a) return;

  if (!Store.getSettings().apiKey) {
    showToast("먼저 ⚙ API 설정에서 Gemini API 키를 입력해 주세요.");
    document.getElementById("settings-modal").hidden = false;
    return;
  }

  openAiModal(`✨ ${a.title} 준비 도우미`, `<p class="loading-line">AI가 내용을 분석하고 있어요...</p>`);

  try {
    const result = await AI.prepareAssessment(a, extraSourceText);

    // merge schedule into the assessment's checklist (keep existing done state by label)
    const prevDone = new Map(a.checklist.map((c) => [c.label, c.done]));
    a.checklist = (result.schedule || []).map((s) => ({
      id: Store.uid(),
      label: s.label || "단계",
      detail: s.detail || "",
      done: prevDone.get(s.label) || false,
    }));
    Store.saveAssessment(a);
    renderBoard();

    Store.addHistory({
      id: Store.uid(),
      assessmentId: a.id,
      assessmentTitle: a.title,
      subject: a.subject,
      type: a.type,
      outline: result.outline || "",
      feedback: result.feedback || "",
      schedule: result.schedule || [],
      createdAt: new Date().toISOString(),
    });
    renderArchive();

    renderAiResult(a, result);
  } catch (e) {
    console.error(e);
    let msg = "AI 분석 중 오류가 발생했어요.";
    if (String(e.message).includes("NO_API_KEY")) msg = "API 키가 필요해요. ⚙ API 설정에서 입력해 주세요.";
    else if (String(e.message).includes("API_ERROR")) msg = "Gemini API 호출에 실패했어요: " + e.message;
    document.getElementById("ai-modal-body").innerHTML = `<p class="loading-line">${escapeHtml(msg)}</p>`;
  }
}

function renderAiResult(assessment, result) {
  const body = document.getElementById("ai-modal-body");
  const outlineHtml = mdLiteToHtml(result.outline || "");
  const scheduleHtml = (result.schedule || [])
    .map((s) => `<li><strong>${escapeHtml(s.label)}</strong> — ${escapeHtml(s.detail || "")}</li>`)
    .join("");
  body.innerHTML = `
    <h4>구조 / 아웃라인</h4>
    ${outlineHtml}
    <h4>준비 일정</h4>
    <ol>${scheduleHtml}</ol>
    <h4>${AI.TYPE_LABEL[assessment.type]} 피드백</h4>
    <p>${escapeHtml(result.feedback || "")}</p>
  `;
}

// very small markdown-ish renderer: ## headings, - bullets, blank lines
function mdLiteToHtml(md) {
  const lines = md.split("\n");
  let html = "";
  let inList = false;
  lines.forEach((line) => {
    const t = line.trim();
    if (t.startsWith("## ")) {
      if (inList) { html += "</ul>"; inList = false; }
      html += `<h4>${escapeHtml(t.slice(3))}</h4>`;
    } else if (t.startsWith("- ")) {
      if (!inList) { html += "<ul>"; inList = true; }
      html += `<li>${escapeHtml(t.slice(2))}</li>`;
    } else if (t === "") {
      if (inList) { html += "</ul>"; inList = false; }
    } else {
      if (inList) { html += "</ul>"; inList = false; }
      html += `<p>${escapeHtml(t)}</p>`;
    }
  });
  if (inList) html += "</ul>";
  return html;
}

// ---------------- archive ----------------
function renderArchive() {
  const all = Store.getHistory();
  const list = document.getElementById("archive-list");
  const empty = document.getElementById("archive-empty");
  list.innerHTML = "";
  empty.hidden = all.length > 0;

  all.forEach((h) => {
    const el = document.createElement("div");
    el.className = "archive-item";
    const date = new Date(h.createdAt).toLocaleString("ko-KR", { dateStyle: "medium", timeStyle: "short" });
    el.innerHTML = `
      <div class="archive-item-head">
        <span>${h.subject ? escapeHtml(h.subject) + " · " : ""}${AI.TYPE_LABEL[h.type] || "기타"}</span>
        <span>${date}</span>
      </div>
      <h3>${escapeHtml(h.assessmentTitle || "제목 없음")}</h3>
    `;
    el.addEventListener("click", () => {
      openAiModal(`📁 ${h.assessmentTitle}`, "");
      renderAiResult({ type: h.type }, h);
    });
    list.appendChild(el);
  });
}

// ---------------- modal / toast helpers ----------------
function bindModals() {
  document.getElementById("ai-modal-close").addEventListener("click", () => {
    document.getElementById("ai-modal").hidden = true;
  });
}
function openAiModal(title, bodyHtml) {
  document.getElementById("ai-modal-title").textContent = title;
  document.getElementById("ai-modal-body").innerHTML = bodyHtml;
  document.getElementById("ai-modal").hidden = false;
}

let toastTimer = null;
function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 3200);
}

function escapeHtml(str) {
  return String(str || "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}
